 var onum=0;
    var closeState=new Array();
    var ch=200;
    function $(id){if(document.getElementById(id)){return document.getElementById(id);}else{alert("没有找到!")}}
    function $tag(id,tagName){return $(id).getElementsByTagName(tagName)}
    var Ds=$tag("DoorP","div");
    var Ts=$tag("DoorP","h2");
    if(Ds.length != Ts.length){alert("初始化失败!");}
    function showMe(Cid,Oid){var h=parseInt(Ds[Cid].style.height);var h2=parseInt(Ds[Oid].style.height);var dH=ch;if(h>0){h=h-Math.ceil(h/3);Ds[Cid].style.height=h+"px";};if(h2<dH){h2=h2+Math.ceil((dH-h2)/3);Ds[Oid].style.height=h2+"px";};if(h<=0&&h2>=dH){clearTimeout(closeState[Cid]);return false;};closeState[Cid] = setTimeout("showMe("+Cid+","+Oid+")");}
    for(var i=0;i<Ds.length;i++){
        if(i==onum){Ds[i].style.height=ch+"px";Ts[i].className="title01";}else{Ds[i].style.height="0px";Ts[i].className="title02";}
        Ts[i].value=i;
        Ts[i].onclick=function(){if(onum==this.value){return false;};
            Ts[onum].className="title02";
            Ts[this.value].className="title01";
            for(var i=0;i<closeState.length;i++){clearTimeout(closeState[i]);}
            showMe(onum,this.value);
            onum=this.value;
        }
    }


function getPathLink(){
	var url = document.location.href;
    var arrStr = url.substring(url.indexOf("?") + 1).split("&");
    // return arrStr;
    var topTab = arrStr[0];
    var topTabArray = topTab.split("=");
    topTab = topTabArray[1];

    var contentTab = arrStr[1];
    var contentTabArray = contentTab.split("=");
    contentTab = contentTabArray[1];

    var contentTab2 = arrStr[2];
    var contentTab2Array = contentTab2.split("=");
    contentTab2 = contentTab2Array[1];

    console.log(topTab);
    console.log(contentTab);
    console.log(contentTab2);

    document.getElementById("topTab").innerHTML = topTab.toUpperCase();
    document.getElementById("topTab").href = "index.html";

    document.getElementById("contentTab").innerHTML = contentTab.toUpperCase();
    document.getElementById("contentTab").href = "SocialNetwork.html";

    document.getElementById("contentTab2").innerHTML = contentTab2.toUpperCase();


}

getPathLink();